import { Component, OnInit } from '@angular/core';
import { CompanyService } from 'src/app/service/company.service';

@Component({
  selector: 'app-list-company',
  templateUrl: './list-company.component.html',
  styleUrls: ['./list-company.component.css']
})
export class ListCompanyComponent implements OnInit {

  CompanyEntity:any;
  constructor(private service:CompanyService) { }

  ngOnInit():void {
    let resp=this.service.getCompany();
    resp.subscribe((data)=>this.CompanyEntity=data);
  }

}
