import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { CompanyEntity } from '../../company'
import { CompanyService } from 'src/app/service/company.service';
@Component({
  selector: 'add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {

  constructor(private service: CompanyService) { }
  
  company:CompanyEntity=new CompanyEntity(0,"",0,"","","","","");
  message:any;

  ngOnInit() {
  }

  public registerNow(){
    let resp=  this.service.addRegistration(this.company);
    resp.subscribe((data)=>this.message=data);
  }


}
