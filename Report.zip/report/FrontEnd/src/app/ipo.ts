export class CompanyEntity{
    

    constructor(
        id:number,
        companyName:string,
        stockExchange:string,
        pricePerShare:string,
        totalNumberOfShare:string,
        openDateTime:string,
        remarks:string
    ){}
}