import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {CompanyEntity} from '../company'
@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private http:HttpClient) { }

  public addRegistration(user)
  {
    return this.http.post("http://localhost:8081/addCompany",user,{responseType:'text' as 'json'});
  }
  
  public getCompany(){
    return this.http.get("http://localhost:8081/company");
  }
}
