/*

public class CompanyEntity {
	@Id
	private long id;
	private String CompanyName;
	private long turnover;
	private String ceo;
	private String BoardOfDirectors;
	@Column(name="stock_exchange")
	private String stockExchange;
	private String sector;
	@Column(name="description")
    private String description;
    ----------------------
    export class user{
    constructor(
        eid:number,
        name:string

    ){}
}
*/

export class CompanyEntity{
    
        id:number;
        CompanyName:string;
        turnover:number;
        ceo:string;
        BoardOfDirectors:string;
        stockExchange:string;
        sector:string;
        description:string



    constructor(
        id:number,
        CompanyName:string,
        turnover:number,
        ceo:string,
        BoarddOfDirectors:string,
        stockExchange:string,
        sector:string,
        description:string
    ){}
}