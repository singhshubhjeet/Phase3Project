package com.sector.sector.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sector.sector.entity.sectorEntity;

@Repository
public interface sectorRepository extends CrudRepository<sectorEntity,Long>{

}
