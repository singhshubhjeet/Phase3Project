package com.sector.sector.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class sectorEntity {

	@Id
	long id;
	String sectorName;
	String Breif;
	
	public sectorEntity() {
	}
	
	public sectorEntity(long id, String sectorName, String breif) {
		super();
		this.id = id;
		this.sectorName = sectorName;
		Breif = breif;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getBreif() {
		return Breif;
	}

	public void setBreif(String breif) {
		Breif = breif;
	}
	
	
	
	
	
}
