package com.sector.sector.application;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sector.sector.company.CompanyEntity;
import com.sector.sector.company.companyInterface;

@Service
public class serviceImpl {
/*
 
@Autowired
companyInterface ci;

public Iterable<String> getStockExchange(){
	Iterable<String> s= ci.getStockExchange();
	return s;
}
	*/
	
	@Autowired
	companyInterface ci;
	
	public Optional<CompanyEntity> getSector(String sector){
		return ci.findBySector(sector);
		
	}

	
}
