package com.sector.sector.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sector.sector.application.serviceImpl;
import com.sector.sector.company.CompanyEntity;

@RestController
public class sectorController {

	@Autowired
	serviceImpl si;
	 
	 @GetMapping("/sector/{sector}")
public Optional<CompanyEntity> getSectorWiseCompany(@PathVariable String sector){
	return si.getSector(sector);
}
	 
	 
	
}
