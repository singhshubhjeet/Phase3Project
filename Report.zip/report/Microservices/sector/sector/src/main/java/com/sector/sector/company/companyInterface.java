package com.sector.sector.company;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
@Repository
@FeignClient("company")
public interface companyInterface {

	/*
	 
	 @Repository
@FeignClient("company")
public interface companyInterface{
	@GetMapping(value="/stockExchange/{stockExchange}")
	public Optional<CompanyEntity> searchStockExchange(@PathVariable(name="stockExchange") String stockExchange);
}

	 
	 */
	
	@GetMapping(value="/sector/{sector}")
	Optional<CompanyEntity> findBySector(@PathVariable(name="sector") String sector);
	
}
