package com.sector.sector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
