package com.stockcharting.excel.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class ErrorResponse {
	private String message;
	private int statusCode;
	private Long timeHappened;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public Long getTimeHappened() {
		return timeHappened;
	}
	public void setTimeHappened(Long timeHappened) {
		this.timeHappened = timeHappened;
	}
	public ErrorResponse(String message, int statusCode, Long timeHappened) {
		super();
		this.message = message;
		this.statusCode = statusCode;
		this.timeHappened = timeHappened;
	}

	public ErrorResponse() {
		
	}

}
