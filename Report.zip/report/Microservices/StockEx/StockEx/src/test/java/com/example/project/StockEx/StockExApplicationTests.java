package com.example.project.StockEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockExApplicationTests {

	@Test
	void contextLoads() {
	}

}
