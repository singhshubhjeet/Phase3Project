package com.example.project.StockEx.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
//import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.StockEx.company.CompanyEntity;
import com.example.project.StockEx.entity.StockExchangeEntity;
import com.example.project.StockEx.service.serviceImpl;


@RestController
public class StockExchangeController {
	
	@Autowired
	serviceImpl si;

@GetMapping("/stockExchange")
Iterable<StockExchangeEntity> getStockExchangeList(){
	return si.getExchangeList();
}

@PostMapping("/addStockExchange")
String addStockExchange(@RequestBody StockExchangeEntity se) {
	return si.addStockExchange(se);
}
/*@GetMapping("/getComp")
public Iterable<String> getcomp(){
	return si.getStockExchange();
}*/

@GetMapping("/stockExchange/{stockExchange}")
Optional<CompanyEntity> getStockExchange(@PathVariable String stockExchange)
{
	return si.getStockExchange(stockExchange);
}

}

