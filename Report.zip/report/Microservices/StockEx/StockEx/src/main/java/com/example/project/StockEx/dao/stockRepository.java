package com.example.project.StockEx.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.project.StockEx.entity.StockExchangeEntity;

@Repository
public interface stockRepository extends CrudRepository<StockExchangeEntity,Long> {

}
