package com.example.project.StockEx.company;

import javax.persistence.Entity;
import javax.persistence.Id;


