package com.example.project.StockEx.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StockExchangeEntity {
	
	@Id
	private long id;
	public StockExchangeEntity(long id, String name, String brief, String contactAddress, String remarks) {
		super();
		this.id = id;
		this.name = name;
		this.brief = brief;
		this.contactAddress = contactAddress;
		this.remarks = remarks;
	}
	
	public StockExchangeEntity() {
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getContactAddress() {
		return contactAddress;
	}
	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	String name;
	String brief;
	String contactAddress;
	String remarks;
}
