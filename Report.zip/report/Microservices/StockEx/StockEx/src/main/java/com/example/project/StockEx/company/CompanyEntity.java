package com.example.project.StockEx.company;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CompanyEntity {
	@Id
	private long id;
	private String CompanyName;
	private long turnover;
	private String ceo;
	private String BoardOfDirectors;
	private String stockExchange;
	private String sector;
	
	public CompanyEntity() {
		
	}
	
	
	public CompanyEntity(long id, String companyName, long turnover, String ceo, String boardOfDirectors,
			String stockExchange, String sector, String description, long stockCode) {
		super();
		this.id = id;
		CompanyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		BoardOfDirectors = boardOfDirectors;
		this.stockExchange = stockExchange;
		this.sector = sector;
		this.description = description;
		StockCode = stockCode;
	}


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	
	
	
	public String getCeo() {
		return ceo;
	}


	public void setCeo(String ceo) {
		this.ceo = ceo;
	}


	public String getStockExchange() {
		return stockExchange;
	}


	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}


	public String getBoardOfDirectors() {
		return BoardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		BoardOfDirectors = boardOfDirectors;
	}
	
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getStockCode() {
		return StockCode;
	}
	public void setStockCode(long stockCode) {
		StockCode = stockCode;
	}
	public long getTurnover() {
		return turnover;
	}

	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}

	private String description;

	private long StockCode;
	
}
