package com.example.project.StockEx.company;


import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


/*@Repository
@FeignClient("company")
public interface companyInterface {
@GetMapping(value="/BSE")
public Iterable<String> getStockExchange() ;


}*/

@Repository
@FeignClient("company")
public interface companyInterface{
	@GetMapping(value="/stockExchange/{stockExchange}")
	public Optional<CompanyEntity> searchStockExchange(@PathVariable(name="stockExchange") String stockExchange);
}
