package com.example.project.StockEx.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.StockEx.company.CompanyEntity;
import com.example.project.StockEx.company.companyInterface;
//import com.example.project.StockEx.company.companyInterface;
import com.example.project.StockEx.dao.stockRepository;
import com.example.project.StockEx.entity.StockExchangeEntity;

@Service
public class serviceImpl {

@Autowired	
stockRepository sr;

@Autowired
companyInterface ci;

public Iterable<StockExchangeEntity> getExchangeList(){
	return sr.findAll();
}

public String addStockExchange(StockExchangeEntity se) {
	sr.save(se);
	return "Stock Exchange Added";
}

/*public Iterable<String> getStockExchange(){
	Iterable<String> s= ci.getStockExchange();
	return s;
}*/
public Optional <CompanyEntity> getStockExchange(String stockExchange){
	return ci.searchStockExchange(stockExchange);
}

}