package com.example.project.StockEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class StockExApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockExApplication.class, args);
	}

}
