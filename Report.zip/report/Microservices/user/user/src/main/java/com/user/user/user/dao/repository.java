package com.user.user.user.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.user.user.user.entity.user;

@Repository
public interface repository extends CrudRepository<user,Integer> {

}
