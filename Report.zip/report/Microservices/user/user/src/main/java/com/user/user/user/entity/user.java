package com.user.user.user.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class user {
@Id
int id;
String username;
String password;
String email;
Boolean activated;
}
