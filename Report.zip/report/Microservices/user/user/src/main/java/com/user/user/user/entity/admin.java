package com.user.user.user.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class admin {
@Id
int id;	
String userName;
String password;
	
}
