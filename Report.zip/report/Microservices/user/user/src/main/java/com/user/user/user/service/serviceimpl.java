package com.user.user.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.user.user.dao.repository;
import com.user.user.user.entity.user;

@Service
public class serviceimpl {
@Autowired
repository repo;
	
	public String addUser(user u) {
		repo.save(u);
		return "New User Added!";
	}
}
