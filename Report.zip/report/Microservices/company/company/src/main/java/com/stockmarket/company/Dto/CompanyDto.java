package com.stockmarket.company.Dto;

public class CompanyDto {

	
	private String CompanyName;
	private String ceo;
	private String BoardOfDirectors;
	private String StockExchange;
	private String sector;
	
	public CompanyDto()
	{
		
	}
	
	public CompanyDto(String companyName, String ceo, String boardOfDirectors, String stockExchange, String sector) {
		super();
		CompanyName = companyName;
		this.ceo = ceo;
		BoardOfDirectors = boardOfDirectors;
		StockExchange = stockExchange;
		this.sector = sector;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBoardOfDirectors() {
		return BoardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		BoardOfDirectors = boardOfDirectors;
	}
	public String getStockExchange() {
		return StockExchange;
	}
	public void setStockExchange(String stockExchange) {
		StockExchange = stockExchange;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	
	
}

