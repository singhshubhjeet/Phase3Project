package com.stockmarket.company.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*
1.	Company Name
2.	Turnover
3.	CEO
4.	Board of Directors
5.	Listed in Stock Exchanges
6.	Sector
7.	Brief writeup
8.	Company Stock code in each Stock Exchange

*/
@Entity
@Table(name="company")
public class CompanyEntity {
	@Id
	private long id;
	private String companyName;
	private long turnover;
	private String ceo;
	private String BoardOfDirectors;
	@Column(name="stock_exchange")
	private String stockExchange;
	private String sector;
	@Column(name="description")
	private String description;
	
	
	
	


	public CompanyEntity(long id, String companyName, long turnover, String ceo, String boardOfDirectors,
			String stockExchange, String sector, String description, long stockCode) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		BoardOfDirectors = boardOfDirectors;
		this.stockExchange = stockExchange;
		this.sector = sector;
		this.description = description;
		StockCode = stockCode;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}

	@Column(name="stockcode")
	private long StockCode;
	public CompanyEntity() {
		
	}
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBoardOfDirectors() {
		return BoardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		BoardOfDirectors = boardOfDirectors;
	}
	
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getStockCode() {
		return StockCode;
	}
	public void setStockCode(long stockCode) {
		StockCode = stockCode;
	}
	public long getTurnover() {
		return turnover;
	}

	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}
	
	
}
