package com.stockmarket.company.Repository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stockmarket.company.Entity.CompanyEntity;



@Repository
public interface CompanyRepository extends CrudRepository<CompanyEntity, Long> {

	
	/*@Query(nativeQuery=true,value="SELECT company_name FROM `company`")
	Iterable<String> searchStockExchange();
*/
	
	Optional<CompanyEntity> findBycompanyName(String companyName);
	
	Optional<CompanyEntity> findBystockExchange(String stockExchange);
	
	Optional<CompanyEntity> findBysector(String sector);
	
}
