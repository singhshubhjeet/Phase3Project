package com.stockmarket.company.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stockmarket.company.Entity.IPODetailEntity;

@Repository
public interface IPORepository extends CrudRepository<IPODetailEntity,Long> {

	Iterable<IPODetailEntity> findBycompanyName(String companyName);
}
