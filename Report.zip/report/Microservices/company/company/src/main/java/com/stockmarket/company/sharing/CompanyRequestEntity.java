package com.stockmarket.company.sharing;

public class CompanyRequestEntity {

}
