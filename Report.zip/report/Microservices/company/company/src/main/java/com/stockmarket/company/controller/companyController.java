package com.stockmarket.company.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.company.Entity.CompanyEntity;
import com.stockmarket.company.Entity.IPODetailEntity;
import com.stockmarket.company.Service.CompanyServiceImpl;
@CrossOrigin("http://localhost:4200")
@RestController
public class companyController {
	
	@Autowired
	CompanyServiceImpl companyService;
	
	@GetMapping("/company/{id}")
	Optional<CompanyEntity> getCompanyDetails(@PathVariable int id){
		return companyService.getAllDetails(id);
	}
	@GetMapping("/company")
	Iterable<CompanyEntity> getAllCompanyDetails(){
		return companyService.getAllCompany();
	}
	
	@GetMapping("/companyName/{companyName}")
	Optional<CompanyEntity> getMatchingCompanies(@PathVariable String companyName){
		return companyService.getMatchingCompanies(companyName);
	}
	
	
	@PostMapping("/addCompany")
	String addCompany(CompanyEntity c) {
		return companyService.addNewCompany(c);
	}
	@PostMapping("/addIPO")
	String addIPO(IPODetailEntity c) {
		return companyService.addNewIPO(c);
	}
	
	
	/*@GetMapping("/BSE")
	Iterable<String> getExchangeList(){
		return companyService.getStockExchange();
	}*/
	@GetMapping("/stockExchange/{stockExchange}")
	Optional<CompanyEntity> searchStockExchange(@PathVariable String stockExchange){
		return companyService.searchByStockExchange(stockExchange);
	}
	
	@GetMapping("/ipoDetails/{companyName}")
	Iterable<IPODetailEntity> getCompanyIPODetails(@PathVariable String companyName){
		return companyService.getCompanyIPODetails(companyName);
	}
	@GetMapping("/sector/{sector}")
	Optional<CompanyEntity> findBySector(@PathVariable String sector){
		return companyService.searchBysector(sector);
	}

}
