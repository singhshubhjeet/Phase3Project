package com.stockmarket.company.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
	public class IPODetailEntity {
	@Id
	long id;
	String companyName; 
	String stockExchange;
	String pricePerShare;
	String totalNumberOfShare;
	String openDateTime;
	String remarks;
	
	
	public IPODetailEntity() {}
	
	
	public IPODetailEntity(long id, String companyName, String stockExchange, String pricePerShare,
			String totalNumberOfShare, String openDateTime, String remarks) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.totalNumberOfShare = totalNumberOfShare;
		this.openDateTime = openDateTime;
		this.remarks = remarks;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public String getPricePerShare() {
		return pricePerShare;
	}
	public void setPricePerShare(String pricePerShare) {
		this.pricePerShare = pricePerShare;
	}
	public String getTotalNumberOfShare() {
		return totalNumberOfShare;
	}
	public void setTotalNumberOfShare(String totalNumberOfShare) {
		this.totalNumberOfShare = totalNumberOfShare;
	}
	public String getOpenDateTime() {
		return openDateTime;
	}
	public void setOpenDateTime(String openDateTime) {
		this.openDateTime = openDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
		
	
	
	

	
	
}
