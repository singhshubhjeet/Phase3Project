package com.stockmarket.company.mapper;

public class CompanyModelMapper {

	//public 
	
}
