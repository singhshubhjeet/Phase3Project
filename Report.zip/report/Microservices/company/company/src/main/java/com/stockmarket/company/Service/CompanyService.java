package com.stockmarket.company.Service;

import java.util.Optional;

import com.stockmarket.company.Entity.CompanyEntity;
import com.stockmarket.company.Entity.IPODetailEntity;

public interface CompanyService {

	Optional<CompanyEntity> getAllDetails(long id);
	//Iterable<String> getStockExchange();
	Optional<CompanyEntity> searchByStockExchange(String stockExchange);
	Iterable<IPODetailEntity> getCompanyIPODetails(String companyName);
	Optional<CompanyEntity> searchBysector(String sector);
	Iterable<CompanyEntity> getAllCompany();
	String addNewCompany(CompanyEntity c);
	String addNewIPO(IPODetailEntity c);
	Optional<CompanyEntity> getMatchingCompanies(String companyName);
}
