package com.stockmarket.company.sharing;

public class CompanyResponseEntity {

}
