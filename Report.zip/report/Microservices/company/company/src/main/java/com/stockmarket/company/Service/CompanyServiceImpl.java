package com.stockmarket.company.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockmarket.company.Entity.CompanyEntity;
import com.stockmarket.company.Entity.IPODetailEntity;
import com.stockmarket.company.Repository.CompanyRepository;
import com.stockmarket.company.Repository.IPORepository;

@Service
public class CompanyServiceImpl implements CompanyService{

	@Autowired
	CompanyRepository cr;
	@Autowired
	IPORepository ir;
	
	public Optional<CompanyEntity> getAllDetails(long ids) {
		return cr.findById(ids);
	
	}
/*	public Iterable<String> getStockExchange(){
		return cr.searchStockExchange();
		
	}*/
	
	
	public Optional<CompanyEntity> searchByStockExchange(String stockExchange){
		return cr.findBystockExchange(stockExchange);
	}


	public Iterable<IPODetailEntity> getCompanyIPODetails(String companyName) {
		// TODO Auto-generated method stub
		return ir.findBycompanyName(companyName);
	}


	public Optional<CompanyEntity> searchBysector(String sector) {
		// TODO Auto-generated method stub
		return cr.findBysector(sector);
	}


	public Iterable<CompanyEntity> getAllCompany() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}


	public String addNewCompany(CompanyEntity c) {
		cr.save(c);
		return "New Company Added!";
	}
	


	public String addNewIPO(IPODetailEntity c) {
		ir.save(c);
		return "New IPO Details Added!";
	}


	public Optional<CompanyEntity> getMatchingCompanies(String companyName) {
		// TODO Auto-generated method stub
		return cr.findBycompanyName(companyName);
	}
}
