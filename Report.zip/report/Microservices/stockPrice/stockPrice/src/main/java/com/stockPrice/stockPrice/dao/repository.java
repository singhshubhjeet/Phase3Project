package com.stockPrice.stockPrice.dao;

import java.sql.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stockPrice.stockPrice.Entity.stockPriceEntity;
@Repository
public interface repository extends CrudRepository<stockPriceEntity,Long>{

	
	//SELECT * FROM `stock_price_entity` WHERE company_id=1 and d BETWEEN '2020-08-01' AND '2020-08-04'
	/*  /*@Query(nativeQuery=true,value="SELECT company_name FROM `company`")
	Iterable<String> searchStockExchange();*/
	
	//@Query("select u from User u where u.emailAddress = ?1")
	
	/*User findByEmailAddress(String emailAddress);
}

@Query(value="SELECT * FROM sku_warehouse sw JOIN warehouse w ON (sw.warehouse_id = w.Id) WHERE w.warehouse_id=?1 AND sw.sku_master_id=?2", nativeQuery = true)
*/

	@Query(value="SELECT * FROM stock_price_entity  WHERE company_id=?1 and d BETWEEN ?2 AND ?3",nativeQuery=true)
	Iterable<String> findcompanyPrice(int id,Date d1,Date d2);
}
