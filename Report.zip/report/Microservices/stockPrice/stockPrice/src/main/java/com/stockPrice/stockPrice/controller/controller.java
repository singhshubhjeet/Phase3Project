package com.stockPrice.stockPrice.controller;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.stockPrice.stockPrice.Entity.stockPriceEntity;
import com.stockPrice.stockPrice.service.serviceImpl;

@RestController
public class controller {

	@Autowired
	serviceImpl s;
	
	/*
	 
@GetMapping("/company/{id}")
	Optional<CompanyEntity> getCompanyDetails(@PathVariable int id){
		return companyService.getAllDetails(id);
	 */
	
@GetMapping("/company/{id}/{d1}/{d2}")
Iterable<String>  search(@PathVariable("id") int id,@PathVariable("d1")Date d1,@PathVariable("d2") Date d2){
	return s.search(id, d1, d2);
}
}
