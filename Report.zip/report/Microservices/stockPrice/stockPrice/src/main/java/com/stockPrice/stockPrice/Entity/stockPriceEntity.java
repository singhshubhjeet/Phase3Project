package com.stockPrice.stockPrice.Entity;

import java.sql.Date;
import java.sql.Time;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * company,stockexchange,price,date,time
 */

@Entity
@Table(name="stock_price_entity")
public class stockPriceEntity {
@Id
long id;
long companyId;
String stockExchange;
float price;
Date d;
String t;
}
