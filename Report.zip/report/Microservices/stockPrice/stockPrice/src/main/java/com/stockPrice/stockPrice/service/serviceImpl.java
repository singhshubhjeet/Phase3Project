package com.stockPrice.stockPrice.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockPrice.stockPrice.Entity.stockPriceEntity;
import com.stockPrice.stockPrice.dao.repository;



@Service
public class serviceImpl {

	@Autowired 
	repository r;
	/*public Optional<CompanyEntity> searchByStockExchange(String stockExchange){
		return cr.findBystockExchange(stockExchange);
	}*/

	public Iterable<String>  search(int id,Date d1,Date d2){
		return r.findcompanyPrice(id, d1, d2) ;
	}
}
