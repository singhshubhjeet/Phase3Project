package com.stockPrice.stockPrice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
