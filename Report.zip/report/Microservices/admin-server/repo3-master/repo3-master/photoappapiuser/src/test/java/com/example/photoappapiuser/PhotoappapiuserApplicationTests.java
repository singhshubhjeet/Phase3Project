package com.example.photoappapiuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoappapiuserApplicationTests {

    @Test
    void contextLoads() {
    }

}
